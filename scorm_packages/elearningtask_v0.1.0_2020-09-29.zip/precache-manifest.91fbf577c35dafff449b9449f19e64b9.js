self.__precacheManifest = [
  {
    "revision": "a6ccb145667f6cc12286c7750cc06e64",
    "url": "./static/media/app_scatch.a6ccb145.png"
  },
  {
    "revision": "67b83b8c6c8b749c5abd",
    "url": "./static/css/main.c35057a5.chunk.css"
  },
  {
    "revision": "5b6f49cff4b5972bcadc",
    "url": "./static/js/runtime~main.34aaec62.js"
  },
  {
    "revision": "9d36e473e1b78d2fd9f9",
    "url": "./static/js/2.7e4f62d9.chunk.js"
  },
  {
    "revision": "d60f8689b24987593d20dba66d5dafdb",
    "url": "./static/media/epilsey.d60f8689.jpg"
  },
  {
    "revision": "380a9874f63e69689635a30fcea68ad2",
    "url": "./static/media/bindingdata.380a9874.png"
  },
  {
    "revision": "64ce1b90cfe9136a3d70da72f86cb6f8",
    "url": "./static/media/table_1.64ce1b90.jpg"
  },
  {
    "revision": "274996ce2935132ba0f06dbda3fa51bb",
    "url": "./static/media/curve.274996ce.png"
  },
  {
    "revision": "67b83b8c6c8b749c5abd",
    "url": "./static/js/main.a1f1a085.chunk.js"
  },
  {
    "revision": "33a777b8f5207b0171ed7b744ed433c6",
    "url": "./static/media/units_curve.33a777b8.png"
  },
  {
    "revision": "18e5ea95f32ed0871516ec983957595b",
    "url": "./static/media/scath_plot.18e5ea95.png"
  },
  {
    "revision": "99404ec6ad3a5fc0ccdc925a24f780f0",
    "url": "./static/media/scatch_graph.99404ec6.png"
  },
  {
    "revision": "92a19aedb2c7e2deacfd8560c2c99c7e",
    "url": "./static/media/theory.92a19aed.png"
  },
  {
    "revision": "5ed82c35cd16804b717f332f2fd4a98f",
    "url": "./static/media/outcomes.5ed82c35.png"
  },
  {
    "revision": "f490cd6835634151d70a8bff249b3b5c",
    "url": "./static/media/logo.f490cd68.png"
  },
  {
    "revision": "7e402396ca428a5bd514c48df615b24e",
    "url": "./static/js/2.7e4f62d9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f9b890ea0361ba66ebd9d1e24306ce25",
    "url": "./index.html"
  }
];